package com.example.navigation.Components

import androidx.compose.material.icons.Icons
import androidx.compose.material3.Icon
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Home
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.tooling.preview.Preview
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.navigation.navigation.AppScreens

@Preview

@Composable
fun NavigationBottomBarPreview(){
    val navController= rememberNavController()
    NavigationBottomBar(navController)
}
@Composable
fun NavigationBottomBar(navController: NavController){
    NavigationBar {
        NavigationBarItem(
            label = {
                    Text(text = "Home")
            },
            selected = false  ,
            onClick = {
                navController.navigate(AppScreens.HomeScreen.route)
            },
            icon = {
                Icon(Icons.Filled.Home,"Home")
            })
        NavigationBarItem(
            label = {
                Text(text = "Config")
            },
            selected = false  ,
            onClick = {
                      navController.navigate(AppScreens.ConfigScreen.route)
            },
            icon = {
                Icon(Icons.Filled.Build,"Config")
            })
    }
}
