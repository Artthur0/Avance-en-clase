package com.example.navigation.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.navigation.Components.NavigationBottomBar

@Preview
@Composable
fun ShowConfigScreenPreview(){
    val navController= rememberNavController()
    ConfigScreen(navController)
}


@Composable
fun ConfigScreen(navController: NavController) {
    Scaffold(
        bottomBar = {
                    NavigationBottomBar(navController)
        },
        content = { paddingValues ->
            Column(modifier = Modifier.padding(paddingValues)) {
                Text(text = "SOY CONFIG SCREEN")
                Button(onClick = {
                    navController.popBackStack()
                }) {
                    Text(text = "VOLVER")
                }
            }
        }
    )
}